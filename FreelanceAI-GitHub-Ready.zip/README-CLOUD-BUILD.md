# Freelance AI — cloud APK build

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

After the project is uploaded to a GitHub repository, open **Actions**, run **Build Freelance AI APK**, and download the `Freelance-AI-debug-apk` artifact. GitHub-hosted runners provide the build machine; the phone does not need an Android IDE.

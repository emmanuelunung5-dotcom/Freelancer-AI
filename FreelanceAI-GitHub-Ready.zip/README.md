# Freelance AI — Dark Manny

A phone-first Android freelance assistant prototype.

Features in this build:
- My Worker chat with task-style conversation
- Freelance categories: design, video, music/audio, writing, tech, marketing, data/admin, AI
- Job analysis workflow
- Proposal helper
- Project workspace
- Wallet/withdrawal area
- Android 10+ support

Important: this build does not secretly control accounts or bypass platform protections. Real platform automation requires each platform's permitted APIs/permissions and your approval for important actions such as submitting applications or withdrawals.

Build in Android Studio or AndroidIDE with Android SDK 35 and Gradle/AGP 8.7.3.
